function showAlert() {
  alert("Hello, this is JavaScript Alert!");
}

showAlert();
