def find_duplicates(arr):
    dup_list = []
    for i in range(len(arr)):
        counter = arr.count(arr[i])
        if counter > 1:
            if arr[i] in dup_list:
                continue
            else:
                dup_list.append(arr[i])
        
    return dup_list

num_list = [1,1,3,3,2,5,7,5,8]
print(find_duplicates(num_list))