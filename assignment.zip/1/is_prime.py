def is_prime(n):
    factors = 0
    for i in range(2,n):
        if n % i == 0:
            factors += 1
        
    if factors > 0:
        return False
    else:
        return True

print(is_prime(23))