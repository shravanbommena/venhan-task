def sum_of_squares(lst):
    sum = 0
    for i in range(len(lst)):
        sum += lst[i]** 2 
    
    return sum

num_list = [1,2,3]

print(sum_of_squares(num_list))