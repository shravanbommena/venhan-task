import sqlite3

def insert_student(name, grade):
    # Connect to the SQLite database (or create it if it doesn't exist)
    conn = sqlite3.connect('students.db')
    cursor = conn.cursor()
    
    # Create the students table if it doesn't exist
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS students (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name VARCHAR(100) NOT NULL,
        grade DECIMAL(3,2) NOT NULL
    )
    ''')
    
    # Insert the new student into the students table
    cursor.execute('''
    INSERT INTO students (name, grade)
    VALUES (?, ?)
    ''', (name, grade))
    
    # Commit the transaction and close the connection
    conn.commit()
    conn.close()

insert_student('John Doe', 3.5)

